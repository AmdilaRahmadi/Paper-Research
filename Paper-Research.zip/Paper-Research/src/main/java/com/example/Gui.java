package com.example;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.awt.event.*;
import java.net.URL;
import java.util.List;
import java.util.HashMap;

public class Gui {
    private HashMap<String, List<String>> searchResultsMap = new HashMap<>();
    private JList<String> resultList;
    private JPanel panel1;
    private JPanel leftPanel;
    private JPanel topPanel;
    private JPanel centerPanel;
    private JPanel rightPanel;
    private JTextField searchField;
    private JButton searchButton;
    private JTextArea descriptionArea;
    private boolean descriptionVisible = false;
    private boolean descriptionLocked = false;

    public Gui() {
        panel1 = new JPanel();
        panel1.setLayout(new BorderLayout());

        // Left : History
        leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(BorderFactory.createTitledBorder("History"));
        leftPanel.setPreferredSize(new Dimension(250, 0));

        // Scroll pane kiri
        JScrollPane leftScrollPane = new JScrollPane(leftPanel);
        leftScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        leftScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        // Receive button
        JButton receiveButton = new JButton("Receive File");
        receiveButton.addActionListener(e -> {
            new Thread(() -> ReceiveFile.startServer(1234)).start();
            JOptionPane.showMessageDialog(panel1, "Server is running. Ready to receive files!");
        });

        // Top : Pencarian
        topPanel = new JPanel(new BorderLayout());
        searchField = new JTextField();
        searchButton = new JButton("Search");
        topPanel.add(searchField, BorderLayout.CENTER);
        topPanel.add(searchButton, BorderLayout.EAST);
        topPanel.add(receiveButton, BorderLayout.WEST);

        // Center : Hasil pencarian
        centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(BorderFactory.createTitledBorder("Search Results"));
        resultList = new JList<>(new DefaultListModel<>());
        JScrollPane resultScrollPane = new JScrollPane(resultList);
        centerPanel.add(resultScrollPane, BorderLayout.CENTER);

        // Right : Deskripsi
        rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(BorderFactory.createTitledBorder("Paper Description"));
        descriptionArea = new JTextArea();
        descriptionArea.setEditable(false);

        // hide/show button
        JButton hideButton = new JButton("Hide");
        hideButton.addActionListener(e -> toggleDescriptionVisibility());

        // Lock button
        JButton lockButton = new JButton("Lock");
        lockButton.addActionListener(e -> {
            descriptionLocked = !descriptionLocked;
            lockButton.setText(descriptionLocked ? "Unlock" : "Lock");
        });

        // Download button
        JButton downloadButton = new JButton("Unduh");
        downloadButton.addActionListener(e -> {
            String selectedPaper = resultList.getSelectedValue();

            if (selectedPaper == null || selectedPaper.isEmpty()) {
                JOptionPane.showMessageDialog(panel1, "Pilih sebuah paper terlebih dahulu.");
                return;
            }

            String fileName = selectedPaper.substring(selectedPaper.lastIndexOf("/") + 1);

            if (!fileName.endsWith(".pdf")) {
                fileName += ".pdf";
            }

            fileName = fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
            String userHome = System.getProperty("user.home");
            String savePath = userHome + "/Downloads/" + fileName;

            try {
                URL url = new URL(selectedPaper);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);

                try (BufferedInputStream in = new BufferedInputStream(connection.getInputStream());
                     BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(savePath))) {

                    int bytesRead;
                    while ((bytesRead = in.read()) != -1) {
                        out.write(bytesRead);
                    }

                    JOptionPane.showMessageDialog(panel1, "Paper berhasil diunduh ke " + savePath);
                }

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(panel1, "Terjadi kesalahan saat mengunduh: " + ex.getMessage());
            }
        });

        // Share button
        JButton sendButton = new JButton("Kirim");
        sendButton.addActionListener(e -> {
            PeerToPeer.startClient();
        });

        JPanel rightTopPanel = new JPanel();
        rightTopPanel.setLayout(new BorderLayout());
        rightTopPanel.add(hideButton, BorderLayout.WEST);
        rightTopPanel.add(lockButton, BorderLayout.EAST);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(downloadButton);
        buttonPanel.add(sendButton);

        rightPanel.add(rightTopPanel, BorderLayout.NORTH);
        rightPanel.add(new JScrollPane(descriptionArea), BorderLayout.CENTER);
        rightPanel.add(buttonPanel, BorderLayout.SOUTH);
        rightPanel.setPreferredSize(new Dimension(0, 0));

        // Add Panel
        panel1.add(leftScrollPane, BorderLayout.WEST);
        panel1.add(topPanel, BorderLayout.NORTH);
        panel1.add(centerPanel, BorderLayout.CENTER);
        panel1.add(rightPanel, BorderLayout.EAST);

        // Event Search
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String query = searchField.getText().trim();
                if (!query.isEmpty()) {
                    // Menambahkan item ke history
                    JPanel historyItemPanel = createHistoryPanel(query);
                    leftPanel.add(historyItemPanel);
                    leftPanel.revalidate();
                    leftPanel.repaint();

                    DefaultListModel<String> resultModel = (DefaultListModel<String>) resultList.getModel();
                    resultModel.clear();

                    new SwingWorker<List<String>, String>() {
                        @Override
                        protected List<String> doInBackground() throws Exception {
                            try {
                                return PaperScrap.searchForPdf(query);
                            } catch (IOException ex) {
                                publish("Terjadi kesalahan saat pencarian: " + ex.getMessage());
                                return null;
                            }
                        }

                        @Override
                        protected void process(List<String> chunks) {
                            // Mengupdate UI berdasarkan hasil pencarian
                            for (String chunk : chunks) {
                                resultModel.addElement(chunk);
                            }
                        }

                        @Override
                        protected void done() {
                            try {
                                List<String> pdfLinks = get();
                                if (pdfLinks == null || pdfLinks.isEmpty()) {
                                    resultModel.addElement("Tidak ditemukan hasil PDF untuk: " + query);
                                } else {
                                    searchResultsMap.put(query, pdfLinks);
                                }
                            } catch (Exception ex) {
                                resultModel.addElement("Terjadi kesalahan saat pencarian: " + ex.getMessage());
                            }
                        }
                    }.execute();
                }
            }
        });

        // Result event
        resultList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selectedPaper = resultList.getSelectedValue();
                if (selectedPaper != null) {
                    descriptionArea.setText(selectedPaper + "\n\nDeskripsi lengkap dari " + selectedPaper + ".");
                    slideInDescription();
                }
            }
        });
    }

    // History panel
    private JPanel createHistoryPanel(String query) {
        JPanel historyPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(new Color(220, 220, 220));
                g2.setStroke(new BasicStroke(1));
                g2.drawRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
            }
        };

        historyPanel.setBackground(new Color(255, 255, 255, 200));

        JPanel buttonPanel = new JPanel(new BorderLayout(0, 0));
        buttonPanel.setOpaque(false);

        JButton closeButton = new JButton("x");
        closeButton.setFont(new Font("Arial", Font.BOLD, 16));
        closeButton.setForeground(new Color(150, 150, 150));
        closeButton.setBorder(BorderFactory.createEmptyBorder());
        closeButton.setContentAreaFilled(false);
        closeButton.setFocusPainted(false);

        closeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeButton.setForeground(Color.RED);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                closeButton.setForeground(new Color(150, 150, 150));
            }
        });

        closeButton.addActionListener(e -> {
            leftPanel.remove(historyPanel);
            leftPanel.revalidate();
            leftPanel.repaint();
        });

        buttonPanel.add(closeButton, BorderLayout.EAST);
        historyPanel.add(buttonPanel, BorderLayout.NORTH);

        JLabel label = new JLabel("<html><p style='width:180px; word-wrap: break-word;'>" + query + "</p></html>");
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setForeground(Color.BLACK);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setVerticalAlignment(SwingConstants.CENTER);

        int labelHeight = label.getPreferredSize().height;

        JPanel labelPanel = new JPanel(new BorderLayout());
        labelPanel.add(label, BorderLayout.CENTER);
        labelPanel.setPreferredSize(new Dimension(180, labelHeight));
        labelPanel.setOpaque(false);

        historyPanel.add(labelPanel, BorderLayout.CENTER);
        historyPanel.setPreferredSize(new Dimension(200, labelHeight + 30));
        historyPanel.setMaximumSize(new Dimension(200, labelHeight + 30));

        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                updateSearchResults(query);
                descriptionArea.setText(query + "\n\nDeskripsi lengkap dari " + query + ".");
                slideInDescription();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                label.setForeground(new Color(100, 100, 255));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                label.setForeground(Color.BLACK);
            }
        });

        return historyPanel;
    }

    // Result per history
    private void updateSearchResults(String query) {
        DefaultListModel<String> resultModel = (DefaultListModel<String>) resultList.getModel();
        resultModel.clear();

        if (searchResultsMap.containsKey(query)) {
            List<String> previousResults = searchResultsMap.get(query);
            for (String result : previousResults) {
                resultModel.addElement(result);
            }
        } else {
            resultModel.addElement("Tidak ada hasil sebelumnya untuk: " + query);
        }
    }

    // Slide in deskripsi
    private void slideInDescription() {
        Timer timer = new Timer(10, new ActionListener() {
            int width = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                if (width < 300) {
                    width += 10;
                    rightPanel.setPreferredSize(new Dimension(width, rightPanel.getHeight()));
                    rightPanel.revalidate();
                } else {
                    ((Timer) e.getSource()).stop();
                }
            }
        });
        timer.start();
    }

    // Hide/Show deskripsi
    private void toggleDescriptionVisibility() {
        descriptionVisible = !descriptionVisible;
        rightPanel.setVisible(descriptionVisible);
    }

    // Get panel
    public JPanel getPanel() {
        return panel1;
    }
}


class PeerToPeer {
    static final int PORT = 1234;

    public static void startClient() {
        // GUI untuk Peer-to-Peer File Transfer
        final File[] fileToSend = new File[1];

        JFrame peerFrame = new JFrame("Peer-to-Peer File Transfer");
        peerFrame.setSize(450, 450);
        peerFrame.setLayout(new BoxLayout(peerFrame.getContentPane(), BoxLayout.Y_AXIS));
        peerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel jlTitle = new JLabel("Peer-to-Peer File Transfer");
        jlTitle.setFont(new Font("Arial", Font.BOLD, 20));
        jlTitle.setBorder(new EmptyBorder(20, 0, 10, 0));
        jlTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel jlFileName = new JLabel("Choose a file to send");
        jlFileName.setFont(new Font("Arial", Font.BOLD, 20));
        jlFileName.setBorder(new EmptyBorder(50, 0, 0, 0));
        jlFileName.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel jpButton = new JPanel();
        jpButton.setBorder(new EmptyBorder(75, 0, 10, 0));

        JButton jbSendFile = new JButton("Send File");
        jbSendFile.setPreferredSize(new Dimension(150, 75));
        jbSendFile.setFont(new Font("Arial", Font.BOLD, 20));

        JButton jbChooseFile = new JButton("Choose File");
        jbChooseFile.setPreferredSize(new Dimension(150, 75));
        jbChooseFile.setFont(new Font("Arial", Font.BOLD, 20));

        jpButton.add(jbSendFile);
        jpButton.add(jbChooseFile);

        jbChooseFile.addActionListener(e -> {
            JFileChooser jFileChooser = new JFileChooser();
            jFileChooser.setDialogTitle("Choose a file to send");

            if (jFileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                fileToSend[0] = jFileChooser.getSelectedFile();
                jlFileName.setText("The file you want to send is: " + fileToSend[0].getName());
            }
        });

        jbSendFile.addActionListener(e -> {
            if (fileToSend[0] == null) {
                jlFileName.setText("Please choose a file first.");
            } else {
                String targetIP = JOptionPane.showInputDialog("Enter the target IP address:");
                if (targetIP != null && !targetIP.isEmpty()) {
                    sendFile(targetIP, PORT, fileToSend[0]);
                }
            }
        });

        peerFrame.add(jlTitle);
        peerFrame.add(jlFileName);
        peerFrame.add(jpButton);
        peerFrame.setVisible(true);
    }

    public static void sendFile(String host, int port, File file) {
        try (Socket socket = new Socket(host, port);
                FileInputStream fis = new FileInputStream(file);
                DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream())) {

            // System.out.println("Sending file to " + host + ":" + port);

            String fileName = file.getName();
            byte[] fileNameBytes = fileName.getBytes();
            byte[] fileContentBytes = new byte[(int) file.length()];
            fis.read(fileContentBytes);

            dataOutputStream.writeInt(fileNameBytes.length);
            dataOutputStream.write(fileNameBytes);

            dataOutputStream.writeInt(fileContentBytes.length);
            dataOutputStream.write(fileContentBytes);
            // System.out.println("File sent successfully!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}